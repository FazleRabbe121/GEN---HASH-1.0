
# GEN — HASH 1.0 | Offline Personal AI Academy

**Package type:** engineering handoff / content foundation / integration blueprint  
**Target:** Android phone, initially Google Pixel 6  
**Relationship to CareerPilot:** isolated optional module; must not replace or modify the existing Gemini integration (`GEN MODEL GEN HASH 1`) or any existing CareerPilot feature.

## What is included

- Offline-first architecture and Android implementation blueprint.
- Multi-level language curricula: English, Spanish, Italian, French, German and Greek.
- A language-course content schema and sample starter lessons.
- A broad bartending, mixology, spirits, cocktails, mocktails, barista and bar-operations knowledge map.
- Local knowledge-base / retrieval design, progress tracking and assessment requirements.
- Offline acceptance tests and safety/quality rules.
- The previously supplied `CareerPilot_AI_Agent_Engineer_Document_Intelligence_v1.1.0.zip`, copied unchanged into this package.

## Important scope and honesty

This is **not a finished Android APK** and it is **not yet uploaded to the user's GitHub repository**. The connected GitHub account returned no accessible repositories at the time this package was prepared.

This package is a structured engineering handoff and content foundation. It does not contain a complete multi-gigabyte LLM, full audio pronunciation recordings for every language, or a complete professionally authored encyclopedia for every topic. Those require model selection, licensing review, content production, device benchmarking and a real build/test cycle. The app must download approved model and voice packs once, then operate offline.

## Identity

- Agent / product name: `GEN`
- Model identity requested by user: `HASH 1.0`
- Suggested internal version string: `gen-hash-1.0`
- Keep the CareerPilot Gemini system separate and unchanged.

## First implementation milestone

Build an isolated Android module/app with:
1. Kotlin + Jetpack Compose.
2. On-device inference runtime selected after compatibility benchmarking.
3. Room/SQLite local database.
4. Downloadable signed model/content/voice packs.
5. Language Academy, Bartending Academy, General Knowledge and private AI Tutor.
6. Offline-only mode that blocks network calls and clearly reports unavailable live features.
7. No automatic job applications or external actions without explicit user approval.

See `docs/ANDROID_IMPLEMENTATION_BLUEPRINT.md`.
