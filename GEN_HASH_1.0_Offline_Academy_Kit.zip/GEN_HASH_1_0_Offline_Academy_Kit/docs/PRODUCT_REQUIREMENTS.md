
# Product requirements — GEN / HASH 1.0

## Product promise
GEN is a private personal AI tutor that teaches in structured steps and remains useful without an internet connection after required packs have been downloaded.

## Primary learning areas
1. Language Academy: English, Spanish, Italian, French, German and Greek initially; expandable language packs.
2. Bartending Academy: spirits, liqueurs, cocktail families, recipes, mixology, mocktails, coffee/barista, service, hygiene, stock and operations.
3. General Knowledge: science, geography, history, technology, mathematics, culture and practical knowledge.
4. AI Tutor: question answering grounded in local lessons and documents, quizzes, revision, role-play and progress feedback.

## Teaching design
Every course should support:
- Beginner / intermediate / advanced progression.
- CEFR mapping for European languages (A1, A2, B1, B2, C1, C2).
- Learning objectives, prerequisites, short lessons, worked examples and practice.
- Pronunciation guidance, listening exercises and spaced repetition where voice packs exist.
- Diagnostic placement test and adaptive review.
- Unit tests and end-of-level assessments.
- Clear correction explanations; never mark a wrong answer as correct.
- Offline content search and bookmarks.
- User-controlled reminders; no manipulative streak pressure.

## Language-specific scope
- English: grammar, vocabulary, pronunciation, listening, speaking, reading, writing, workplace English, hospitality English, interviews and customer service.
- Spanish / Italian / French / German / Greek: pronunciation, alphabet/sound system where relevant, core grammar, vocabulary, everyday dialogues, listening, reading, writing and practical hospitality dialogues.
- Language packs must state whether audio is included, the accent/variety, and the pack version.

## Bartending learning scope
- Foundations and responsible alcohol service.
- Spirit production, categories and styles.
- Liqueurs, aperitifs, vermouths, bitters and modifiers.
- Classic and contemporary cocktail families.
- Mocktails and non-alcoholic menu development.
- Syrups, shrubs, infusions, garnishes and batching.
- Coffee and barista skills.
- Glassware, ice, tools and techniques.
- Guest service, upselling without pressure, complaints and communication.
- Mise en place, inventory, costing, waste, hygiene and safety.
- Practical assessments and recipe scaling.

## Safety / accuracy
- Teach legal drinking age and service rules as jurisdiction-specific, not universal.
- Include responsible service, intoxication recognition, refusal-of-service scenarios and safe transport.
- Never encourage excessive drinking, drinking games, rapid consumption or unsafe home distillation.
- Recipe alcohol quantities are educational; learners must follow local law and venue policy.
- Mark disputed historical origins and regional variations as such.
- Food allergies, cross-contamination, sanitation and equipment safety must be covered.
