
# Content quality policy

Every authored lesson must have:
- Unique stable ID and language/subject code.
- Level, module, lesson title and measurable objectives.
- Explanation in clear learner-appropriate language.
- Examples with translations where applicable.
- Practice tasks and answer key with explanations.
- Source/reviewer metadata for factual specialist content.
- Last-reviewed date and content version.
- Safety notes where the subject requires them.

For language teaching, distinguish standard grammar from regional variants. For Spanish, identify varieties (e.g. Spain / Latin America); for English, identify accent target (e.g. international / UK / US). Do not label one accent as the only correct accent.

For spirits and cocktail history, cite reputable books, producers, standards bodies or institutional sources in the content production pipeline. If exact provenance is uncertain, say so. Recipes may vary by region and venue.

Do not fabricate a claim that all world knowledge is embedded. The local model's base knowledge is finite; use a curated, searchable local knowledge base and clearly identify when the answer is uncertain or outside installed packs.
