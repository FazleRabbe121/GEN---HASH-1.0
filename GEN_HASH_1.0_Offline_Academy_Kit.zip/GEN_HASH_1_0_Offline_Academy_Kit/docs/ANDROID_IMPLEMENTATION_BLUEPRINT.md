
# Android implementation blueprint

## Recommended app structure

`app`
- `feature-home`
- `feature-language-academy`
- `feature-bartending-academy`
- `feature-general-knowledge`
- `feature-ai-tutor`
- `feature-download-manager`
- `feature-progress`
- `core-database`
- `core-content`
- `core-inference`
- `core-audio`
- `core-security`
- `core-network-policy`

Use Kotlin and Jetpack Compose. Keep GEN isolated from CareerPilot's existing Gemini service. If the current CareerPilot app is web-only, build GEN as a separate Android application rather than pretending a web module can run a local LLM offline.

## Local-first data flow

1. User installs the app.
2. A first-run setup explains storage requirements and lets the user download a compatible model and selected content/audio packs over Wi-Fi.
3. Packs are verified using SHA-256 checksums and signed manifest metadata.
4. Packs are stored in app-private storage.
5. In airplane mode, the local model, local database, lessons, quizzes, bookmarks and progress remain available.
6. Network-dependent features are disabled with a clear explanation.

## On-device model selection

Do not hard-code a model until it has been benchmarked on the actual target device. Evaluate:
- Android runtime support and Pixel 6 compatibility.
- RAM footprint, context length, token speed, thermal behaviour and battery use.
- Quantized model quality for multilingual tutoring.
- Commercial and redistribution licence.
- Prompt injection resistance and grounded-answer behaviour.

A compact quantized model is the sensible first target for a Pixel 6-class phone. Do not promise frontier-model quality or unlimited knowledge offline. Larger models may cause slow responses, memory pressure, heat and battery drain.

## Storage planning

The app must calculate real pack sizes from signed manifests and show the user:
- Model size.
- Language text pack size.
- Audio pack size.
- Bartending / general knowledge pack size.
- Required free-space safety margin.
Do not show a fixed storage estimate as a guarantee.

## Audio
Use independently downloadable offline speech-to-text and text-to-speech packs. Provide text-only fallback if a language voice pack is unavailable. Do not imply offline speech works before its models are installed.

## Privacy
- Keep learning history and personal notes on-device by default.
- No analytics or cloud sync in offline mode unless separately enabled by the user.
- Encrypt sensitive local data where appropriate.
- Do not put API keys or service secrets in the APK.
- Provide delete/export controls for local learning data.

## CareerPilot integration boundary
- Add a new GEN entry point only after user approval.
- Do not rename, replace, edit or remove `GEN MODEL GEN HASH 1`.
- Do not change existing Gemini prompts, endpoints, keys, model selection, job search, CV Gallery, Gmail sender, interview portal or existing navigation.
- Use a feature flag: `genOfflineEnabled=false` by default until user testing and explicit approval.
- Prefer a separate Android app/repository if the host app architecture cannot guarantee isolation.

## Build and release
- Build debug APK in CI.
- Run unit tests, content schema validation and static checks.
- Run Android instrumentation tests where an emulator is available.
- Produce a signed release only after signing configuration is securely set up.
- User must install and test on the physical Pixel 6. Remote CI cannot verify microphone quality, thermal behaviour or real-world offline performance.
