
# Bartending knowledge map — production content backlog

This is the taxonomy for a curated local reference library. Each topic should become short lessons, illustrated technique cards, glossary entries, quizzes and practical scenarios.

## 1. Spirits
- Whisky/whiskey: Scotch, Irish, American bourbon, rye, Tennessee, Canadian, Japanese and other regional styles; grain, mash bill, fermentation, distillation, cask maturation, age statements, single malt, single grain, blended malt, blended whisky, cask strength and finishing.
- Gin: juniper requirement, London Dry, distilled gin, compound gin, Old Tom, Navy Strength, contemporary styles, botanicals and production.
- Rum: molasses and fresh cane juice, pot/column distillation, white/gold/dark, aged, agricole, overproof, regional styles and labelling differences.
- Tequila and mezcal: agave species, production regions, cooking, extraction, fermentation, distillation, blanco/reposado/añejo/extra añejo, mezcal categories and denomination rules.
- Vodka: raw materials, distillation, filtration, texture and flavour.
- Brandy: Cognac, Armagnac, grape brandy, fruit brandy, maturation and classifications.
- Other categories: cachaça, pisco, aquavit, soju, baijiu and regional spirits.

## 2. Liqueurs and modifiers
Orange liqueurs, coffee liqueurs, herbal liqueurs, amaro, crème liqueurs, fruit liqueurs, nut liqueurs, anise spirits, vermouth, aromatised wine, aperitifs, digestifs, cocktail bitters and non-alcoholic bitters. Include sweetness, ABV, flavour role and substitutions.

## 3. Cocktail construction
Balance: spirit, sugar, acid, bitterness, dilution, temperature, aroma and texture. Teach recipe notation in ml and oz, standardise house specs, and explain regional variations.

## 4. Classic cocktail families and examples
Sour (Whisky Sour, Daiquiri, Margarita), highball (Gin & Tonic, Cuba Libre), stirred spirit-forward (Martini, Manhattan, Negroni, Old Fashioned), fizz and Collins, spritz, julep, smash, flip, cobbler, tropical/tiki-inspired families. Explain each recipe as a family example, not an immutable universal formula.

## 5. Techniques
Build, shake, dry shake, reverse dry shake, stir, strain, double strain, fine strain, muddle, roll, throw, layer, rinse, flame only under approved venue safety procedures, garnish, batch and control dilution. Explain when and why each technique is used.

## 6. Non-alcoholic and low/no alcohol
Zero-proof menu design, tea/coffee/citrus/bitter/floral/fermented flavour structures, non-alcoholic distillates, sugar-acid balance, carbonation, garnish and avoiding misleading claims. Clearly distinguish 0.0% from low-alcohol products.

## 7. Syrups, purées and house preparations
Simple syrup, rich syrup, demerara syrup, honey syrup, ginger syrup, grenadine, orgeat, gomme, fruit syrups, shrubs, cordials, oleo-saccharum, infusions and purées. Include food safety, refrigeration, date labels, batch records and discard rules. Do not give unsafe preservation guarantees.

## 8. Coffee and barista
Arabica/Robusta, origin and processing, roast, espresso machine parts, grinder calibration, dose/yield/time, extraction, channeling, puck prep, milk temperature/texture, latte art, filter brewing, iced coffee, cleaning and service.

## 9. Operations and professional service
Opening/closing checklist, mise en place, glass polishing, ice management, stock receiving, FIFO/FEFO, par levels, stock counts, wastage, cash handling, POS, shift handover, customer communication, complaints and teamwork.

## 10. Safety and responsible service
Local licensing rules, age verification, intoxication signs, refusal of service, water/food alternatives, safe transport, allergens, cross-contamination, broken glass, chemical handling, burns, cuts, lifting and emergency response. The app must teach users to follow local law and venue policy.
