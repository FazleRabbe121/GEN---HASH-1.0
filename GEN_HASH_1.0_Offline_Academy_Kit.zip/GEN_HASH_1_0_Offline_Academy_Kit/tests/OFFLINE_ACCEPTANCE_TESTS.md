
# GEN offline acceptance tests

## Installation and packs
- [ ] Fresh install clearly explains that model/audio/content packs must be downloaded before offline use.
- [ ] Download manager shows actual byte sizes, progress, pause/resume and free-space checks.
- [ ] SHA-256 mismatch or invalid signature rejects the pack.
- [ ] Interrupted downloads resume safely without corrupting existing packs.
- [ ] User can remove optional packs and see the storage reclaimed.

## Airplane-mode tests
- [ ] Enable airplane mode and force-stop/reopen the app.
- [ ] Local chat works using the installed model.
- [ ] English, Spanish, Italian, French, German and Greek lessons open from local storage.
- [ ] Bartending lessons, glossary, recipes and quizzes open locally.
- [ ] Search, bookmarks, notes and progress work locally.
- [ ] No hidden network request is required for core learning.
- [ ] Network-only features clearly show “Internet required” and do not pretend to work.

## Learning quality
- [ ] Placement test routes learners to an appropriate level.
- [ ] Lessons have objectives, explanations, examples and practice.
- [ ] Wrong answers receive useful correction and explanation.
- [ ] CEFR level and language variety are visible.
- [ ] Local AI answers cite the installed lesson/source where possible and admits uncertainty.

## Pixel 6 performance
- [ ] Measure cold start, warm start, tokens/second, peak RAM, battery use and device temperature.
- [ ] Test long conversations and context truncation.
- [ ] Test switching between model and voice packs without app crash.
- [ ] Test low-storage and memory-pressure scenarios.
- [ ] Test microphone permission, speech recognition and TTS separately for each installed language.

## Regression protection
- [ ] CareerPilot existing Gemini model identifier and service remain unchanged.
- [ ] Existing CV Gallery, job discovery, application tracking, Gmail workflow and Interview Center pass regression tests.
- [ ] GEN feature flag defaults to false.
- [ ] No external job application or email is sent by GEN without user confirmation.
